/**
 * A classe HeartRates representa a calculadora de frequência cardíaca alvo.
 * Os atributos da classe incluem nome, sobrenome e data de nascimento da pessoa.
 * A classe também fornece métodos para calcular a idade, frequência cardíaca máxima
 * e frequência cardíaca alvo da pessoa.
 */


import java.util.Scanner;

public class HeartRates {
    private String nome;
    private String sobrenome;
    private int diaNascimento;
    private int mesNascimento;
    private int anoNascimento;

    public HeartRates(String nome, String sobrenome, int diaNascimento, int mesNascimento, int anoNascimento) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.diaNascimento = diaNascimento;
        this.mesNascimento = mesNascimento;
        this.anoNascimento = anoNascimento;
    }

    // Métodos getters e setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public int getDiaNascimento() {
        return diaNascimento;
    }

    public void setDiaNascimento(int diaNascimento) {
        this.diaNascimento = diaNascimento;
    }

    public int getMesNascimento() {
        return mesNascimento;
    }

    public void setMesNascimento(int mesNascimento) {
        this.mesNascimento = mesNascimento;
    }

    public int getAnoNascimento() {
        return anoNascimento;
    }

    public void setAnoNascimento(int anoNascimento) {
        this.anoNascimento = anoNascimento;
    }

    // Método para calcular a idade em anos
    public int calcularIdade() {
        int anoAtual = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);
        int idade = anoAtual - anoNascimento;
        if (mesNascimento > java.util.Calendar.getInstance().get(java.util.Calendar.MONTH) + 1
                || (mesNascimento == java.util.Calendar.getInstance().get(java.util.Calendar.MONTH) + 1
                        && diaNascimento > java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_MONTH))) {
            idade--;
        }
        return idade;
    }

    // Método para calcular a frequência cardíaca máxima
    public int calcularFrequenciaCardiacaMaxima() {
        return 220 - calcularIdade();
    }

    // Método para calcular a frequência cardíaca alvo
    public String calcularFrequenciaCardiacaAlvo() {
        int frequenciaMaxima = calcularFrequenciaCardiacaMaxima();
        int minimoAlvo = (int) (frequenciaMaxima * 0.5);
        int maximoAlvo = (int) (frequenciaMaxima * 0.85);
        return minimoAlvo + " - " + maximoAlvo;
    }
}

