public class Livro {
    private String titulo;
    private int qtdPaginas;
    private int paginasLidas;

    // Métodos getters e setters
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getQtdPaginas() {
        return qtdPaginas;
    }

    public void setQtdPaginas(int qtdPaginas) {
        this.qtdPaginas = qtdPaginas;
    }

    public int getPaginasLidas() {
        return paginasLidas;
    }

    public void setPaginasLidas(int paginasLidas) {
        this.paginasLidas = paginasLidas;
    }

    // Método para verificar progresso de leitura
    public void verificarProgresso() {
        double porcentagem = (double) paginasLidas * 100 / qtdPaginas;
        System.out.println("Você já leu " + porcentagem + " por cento do livro");
    }
}
