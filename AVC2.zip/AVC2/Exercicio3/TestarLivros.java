public class TestarLivros {
    public static void main(String[] args) {
        // Criando objeto livrofavorito do tipo Livro
        Livro livrofavorito = new Livro();

        // Alterando os atributos do livrofavorito
        livrofavorito.setTitulo("O Pequeno Príncipe");
        livrofavorito.setQtdPaginas(98);

        // Imprimindo informações do livrofavorito
        System.out.println("O livro " + livrofavorito.getTitulo() + " possui " + livrofavorito.getQtdPaginas() + " páginas");

        // Alterando a quantidade de páginas lidas
        livrofavorito.setPaginasLidas(20);

        // Verificando progresso de leitura
        livrofavorito.verificarProgresso();

        // Alterando a quantidade de páginas lidas novamente
        livrofavorito.setPaginasLidas(50);

        // Verificando progresso de leitura novamente
        livrofavorito.verificarProgresso();

        // Instanciando outros 10 livros e chamando os métodos desenvolvidos
        for (int i = 1; i <= 10; i++) {
            Livro livro = new Livro();
            livro.setTitulo("Livro " + i);
            livro.setQtdPaginas(100 + i * 10);
            livro.setPaginasLidas(30 + i * 5);
            livro.verificarProgresso();
        }
    }
}
