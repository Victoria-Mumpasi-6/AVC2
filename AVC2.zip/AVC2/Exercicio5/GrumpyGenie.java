// Classe GrumpyGenie
public class GrumpyGenie {
    private boolean grantedWish;

    public GrumpyGenie() {
        this.grantedWish = false;
    }

    public boolean grantWish() {
        if (!grantedWish) {
            grantedWish = true;
            return true;
        }
        return false;
    }

    public boolean hasGrantedWish() {
        return grantedWish;
    }

    @Override
    public String toString() {
        if (grantedWish) {
            return "Grumpy genie has granted a wish.";
        } else {
            return "Grumpy genie has a wish to grant.";
        }
    }
}