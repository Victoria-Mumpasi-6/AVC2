// Classe ArabianNights
public class ArabianNights {
    public static void main(String[] args) {
        MagicLamp lamp = new MagicLamp(4);

        System.out.println("Creating a magic lamp with capacity for 4 genies.");
        System.out.println("Rubbing the lamp 5 times, indicating the numbers of wishes 2, 3, 4, 5, 1.");

        lamp.rub(2);
        lamp.rub(3);
        lamp.rub(4);
        lamp.rub(5);
        lamp.rub(1);

        FriendlyGenie genie1 = new FriendlyGenie(2);
        FriendlyGenie genie2 = new FriendlyGenie(3);
        FriendlyGenie genie3 = new FriendlyGenie(4);
        FriendlyGenie genie4 = new FriendlyGenie(5);

        System.out.println(genie1);
        System.out.println(genie2);
        System.out.println(genie3);
        System.out.println(genie4);

        System.out.println("Making a wish to each genie.");

        System.out.println("Genie 1: " + (genie1.grantWish() ? "Wish granted!" : "No wishes left."));
        System.out.println("Genie 2: " + (genie2.grantWish() ? "Wish granted!" : "No wishes left."));
        System.out.println("Genie 3: " + (genie3.grantWish() ? "Wish granted!" : "No wishes left."));
        System.out.println("Genie 4: " + (genie4.grantWish() ? "Wish granted!" : "No wishes left."));

        System.out.println(genie1);
        System.out.println(genie2);
        System.out.println(genie3);
        System.out.println(genie4);

        System.out.println("Making another wish to each genie.");

        System.out.println("Genie 1: " + (genie1.grantWish() ? "Wish granted!" : "No wishes left."));
        System.out.println("Genie 2: " + (genie2.grantWish() ? "Wish granted!" : "No wishes left."));
        System.out.println("Genie 3: " + (genie3.grantWish() ? "Wish granted!" : "No wishes left."));
        System.out.println("Genie 4: " + (genie4.grantWish() ? "Wish granted!" : "No wishes left."));

        System.out.println(genie1);
        System.out.println(genie2);
        System.out.println(genie3);
        System.out.println(genie4);

        RecyclableDemon demon = new RecyclableDemon();

        System.out.println("Putting the recyclable demon in the lamp.");
        lamp.feedDemon();

        lamp.rub(7);

        System.out.println(demon);
    }
}
