// Classe RecyclableDemon
public class RecyclableDemon {
    private int grantedWishes;
    private boolean recycled;

    public RecyclableDemon() {
        this.grantedWishes = 0;
        this.recycled = false;
    }

    public boolean grantWish() {
        if (!recycled) {
            grantedWishes++;
            return true;
        }
        return false;
    }

    public void recycle() {
        recycled = true;
    }

    public boolean recycled() {
        return recycled;
    }

    public int getGrantedWishes() {
        return grantedWishes;
    }

    @Override
    public String toString() {
        if (recycled) {
            return "Demon has been recycled.";
        } else {
            return "Recyclable demon has granted " + grantedWishes + " wishes.";
        }
    }
}