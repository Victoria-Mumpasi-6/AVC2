// Classe MagicLamp
public class MagicLamp {
    private int geniesCapacity;
    private int geniesLeft;
    private int demonsCharged;

    public MagicLamp(int geniesCapacity) {
        this.geniesCapacity = geniesCapacity;
        this.geniesLeft = geniesCapacity;
        this.demonsCharged = 0;
    }

    public int getGenies() {
        return geniesLeft;
    }

    public int getDemons() {
        return demonsCharged;
    }

    public void rub(int wishes) {
        if (geniesLeft > 0) {
            geniesLeft--;
            if (wishes % 2 == 0) {
                System.out.println("A genie appears in a bad mood.");
            } else {
                System.out.println("A friendly genie appears.");
            }
        } else {
            System.out.println("A mischievous demon appears.");
        }
    }

    public void feedDemon() {
        demonsCharged++;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MagicLamp)) {
            return false;
        }
        MagicLamp other = (MagicLamp) obj;
        return this.geniesCapacity == other.geniesCapacity && this.geniesLeft == other.geniesLeft && this.demonsCharged == other.demonsCharged;
    }
}