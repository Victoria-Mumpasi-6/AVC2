// Classe FriendlyGenie
public class FriendlyGenie {
    private int grantedWishes;
    private int remainingWishes;

    public FriendlyGenie(int totalWishes) {
        this.grantedWishes = 0;
        this.remainingWishes = totalWishes;
    }

    public boolean grantWish() {
        if (remainingWishes > 0) {
            grantedWishes++;
            remainingWishes--;
            return true;
        }
        return false;
    }

    public int getGrantedWishes() {
        return grantedWishes;
    }

    public int getRemainingWishes() {
        return remainingWishes;
    }

    public boolean canGrantWish() {
        return remainingWishes > 0;
    }

    @Override
    public String toString() {
        return "Friendly genie has granted " + grantedWishes + " wishes and still has " + remainingWishes + " to grant.";
    }
}