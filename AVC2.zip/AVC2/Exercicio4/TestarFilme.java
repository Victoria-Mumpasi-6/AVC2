public class TestarFilme {
    public static void main(String[] args) {
        // Criando objeto filme1 do tipo Filme
        Filme filme1 = new Filme();

        // Alterando os atributos do filme1
        filme1.setTitulo("Os Vingadores");
        filme1.setDuracaoEmMinutos(142);

        // Chamando o método exibirDuracaoEmHoras() para mostrar a duração do filme1
        filme1.exibirDuracaoEmHoras();

        // Criando objeto filme2 do tipo Filme
        Filme filme2 = new Filme();

        // Alterando os atributos do filme2
        filme2.setTitulo("Hotel Transilvânia");
        filme2.setDuracaoEmMinutos(93);

        // Chamando o método exibirDuracaoEmHoras() para mostrar a duração do filme2
        filme2.exibirDuracaoEmHoras();

        // Exibindo os títulos dos filmes em cartaz
        System.out.println("Os filmes em cartaz são " + filme1.getTitulo() + " e " + filme2.getTitulo());

        // Instanciando outros 5 filmes e fazendo as mesmas ações descritas acima
        for (int i = 3; i <= 7; i++) {
            Filme filme = new Filme();
            filme.setTitulo("Filme " + i);
            filme.setDuracaoEmMinutos(120 + i * 10);
            filme.exibirDuracaoEmHoras();
        }
    }
}
